# mask_demo > ytq
https://universe.roboflow.com/imau/mask_demo-g9dka

Provided by a Roboflow user
License: CC BY 4.0

