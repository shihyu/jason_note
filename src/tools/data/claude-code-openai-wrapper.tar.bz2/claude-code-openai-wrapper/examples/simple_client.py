#!/usr/bin/env python3
"""簡單的 Claude Code OpenAI Wrapper 客戶端範例"""

from openai import OpenAI

# 連接到本地 Claude Code OpenAI Wrapper
client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="dummy"  # Claude CLI 模式不需要真實 API key
)

# 請求 Claude 4.5 Sonnet 生成 C++ sort 代碼
response = client.chat.completions.create(
    model="claude-sonnet-4-5",
    messages=[
        {
            "role": "user",
            "content": "請幫我寫一個 C++ quick sort 實作，包含詳細註解"
        }
    ],
    max_tokens=4096
)

# 輸出結果
print("=" * 60)
print("Claude 4.5 Sonnet 生成的 C++ Quick Sort 代碼：")
print("=" * 60)
print(response.choices[0].message.content)
print("=" * 60)
print(f"\n使用模型: {response.model}")
print(f"Token 使用: {response.usage.total_tokens}")
